package es.studium.pmdm_tema_2_practica;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    Button btnBorrar;
    Button btnConfirmar;
    Button btnTraducir;

    EditText nombre;
    EditText apellidos;
    EditText edad;

    RadioGroup genero;
    RadioButton hombre;
    RadioButton mujer;
    RadioButton generoElegido;

    Spinner estadocivil;

    Switch hijos;
    String tenerhijos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.app_name));

        btnBorrar = findViewById(R.id.botonBorrar);
        btnConfirmar = findViewById(R.id.botonConfirmar);
        btnTraducir = findViewById(R.id.botonTranslate);

        btnBorrar.setOnClickListener(this);
        btnConfirmar.setOnClickListener(this);
        btnTraducir.setOnClickListener(this);

        nombre = (EditText) findViewById(R.id.EscribirNombre);
        apellidos = (EditText) findViewById(R.id.EscribirApellidos);
        edad = (EditText) findViewById(R.id.EscribirEdad);

        genero = (RadioGroup) findViewById(R.id.grupoGenero);
        hombre = (RadioButton) findViewById(R.id.radioMasculino);
        mujer = (RadioButton) findViewById(R.id.radioFemenino);

        estadocivil = (Spinner) findViewById(R.id.spinner);

        hijos = (Switch) findViewById(R.id.SwitchHijos);
        hijos.setOnClickListener(this);



        Switch simpleSwitch = findViewById(R.id.SwitchHijos);
        simpleSwitch.setTextOff("No");
        simpleSwitch.setTextOn("Sí");
    }

    @Override
    public void onClick(View view)
    {

        // cojo el ID del botón seleccionado
        int selectedId = genero.getCheckedRadioButtonId();

        // encuentro el botón según el ID para después mostrar su texto
        generoElegido = (RadioButton) findViewById(selectedId);

        if(hijos.isChecked())
        {
            tenerhijos = this.getString(R.string.tiene_hijos);
        }
        else
        {
            tenerhijos = this.getString(R.string.no_tiene_hijos);
        }

        switch (view.getId())
        {
            case R.id.botonConfirmar:
                Toast.makeText(this, nombre.getText() + "," + apellidos.getText() + "," + edad.getText().toString() + "," + generoElegido.getText() + "," + estadocivil.getSelectedItem().toString() + "," + tenerhijos, Toast.LENGTH_LONG).show();
                break;
            case R.id.botonBorrar:
                nombre.setText("");
                apellidos.setText("");
                edad.setText("");
                estadocivil.setSelection(0);
                hijos.setSelected(false);
                genero.clearCheck();
                if(hijos.isChecked())
                {
                    hijos.setChecked(false);
                }
                break;
            case R.id.botonTranslate:
                    if(getResources().getString(R.string.app_name).equals("Personal Data"))
                    {
                        setLocale("sp");
                        recreate();
                    }
                    else {
                        setLocale("en");
                        recreate();
                    }

        }
    }
    private void setLocale(String lang)
    {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_lang", lang);
        editor.apply();
    }
    public void loadLocale()
    {
        SharedPreferences prefs = getSharedPreferences("Settings", Activity.MODE_PRIVATE);
        String language = prefs.getString("My_lang","");
        setLocale(language);
    }
}